import os
from .core.tempprint import (
    tprint,
    temp_print,
    inline_print,
    overwrite_print,
    line,
    header,
    box,
    success,
    error,
    warn,
    highlight,
    logo_temp_live
)

from .core.file import (
    read_file,
    create_txt,
    create_py,
    edit_file,
)

from .core.project import (
    create_python_project,
)

from .core.terminal import (
    list_files,
    delete_file,
    rename_file,
    copy_file,
    move_file,
    change_dir,
    goto_sdcard
)

from .core.ai import (
    ai_generate,
    ai_explain_file,
    ai_summarize_file
)


# ============================
#  CLEAR SCREEN
# ============================

def clear():
    os.system("cls" if os.name == "nt" else "clear")


# ============================
#  MAIN MENU
# ============================

def main_menu():
    print("\n=== TEMPRINT  ===")
    print("1) Read File")
    print("2) AI Explain File")
    print("3) AI Summarize File")
    print("4) Create TXT")
    print("5) Create PY")
    print("6) Edit File")
    print("7) Create Python Project")
    print("8) List Files")
    print("9) Delete File")
    print("10) Rename File")
    print("11) Copy File")
    print("12) Move File")
    print("13) Change Directory")
    print("14) /sdcard")
    print("15) Ask AI")
    print("16) Print Tools")
    print("17) Exit")
    return input("Select: ")


# ============================
#  PRINT TOOL MENU
# ============================

def print_menu():
    clear()
    print("\n=== PRINT TOOLS ===")
    print("1) temp_print")
    print("2) inline_print")
    print("3) overwrite_print")
    print("4) line")
    print("5) header")
    print("6) box")
    print("7) success")
    print("8) error")
    print("9) warning")
    print("10) highlight")
    print("11) logo_temp_live")
    print("12) Back")
    return input("Choose: ")


# ============================
#  MAIN CLI LOOP
# ============================

def main():
    clear()
    print("Welcome to Temprint CLI")

    while True:
        choice = main_menu()

        # READ FILE
        if choice == "1":
            path = input("Path: ")
            print(read_file(path))

        # AI EXPLAIN FILE
        elif choice == "2":
            path = input("File: ")
            print(ai_explain_file(path))

        # AI SUMMARIZE
        elif choice == "3":
            path = input("File: ")
            print(ai_summarize_file(path))

        # CREATE TXT
        elif choice == "4":
            path = input("File name: ")
            text = input("Content: ")
            print(create_txt(path, text))

        # CREATE PY
        elif choice == "5":
            path = input("File name: ")
            code = input("Code: ")
            print(create_py(path, code))

        # EDIT FILE
        elif choice == "6":
            path = input("File: ")
            print(edit_file(path))

        # PROJECT GENERATOR
        elif choice == "7":
            name = input("Project name: ")
            print(create_python_project(name))

        # LIST FILES
        elif choice == "8":
            print(list_files())

        # DELETE
        elif choice == "9":
            path = input("File: ")
            print(delete_file(path))

        # RENAME
        elif choice == "10":
            old = input("Old: ")
            new = input("New: ")
            print(rename_file(old, new))

        # COPY
        elif choice == "11":
            a = input("Source: ")
            b = input("Target: ")
            print(copy_file(a, b))

        # MOVE
        elif choice == "12":
            a = input("Source: ")
            b = input("Target: ")
            print(move_file(a, b))

        # CD
        elif choice == "13":
            path = input("Path: ")
            print(change_dir(path))

        # SDCARD
        elif choice == "14":
            print(goto_sdcard())

        # ASK AI
        elif choice == "15":
            prompt = input("Ask AI: ")
            print(ai_generate(prompt))

        # PRINT TOOLS MENU
        elif choice == "16":
            while True:
                sub = print_menu()

                if sub == "1":
                    temp_print(input("Text: "), 2)

                elif sub == "2":
                    inline_print(input("Text: "))

                elif sub == "3":
                    overwrite_print(input("Text: "))

                elif sub == "4":
                    line()

                elif sub == "5":
                    header(input("Header: "))

                elif sub == "6":
                    box(input("Text: "))

                elif sub == "7":
                    success(input("Text: "))

                elif sub == "8":
                    error(input("Text: "))

                elif sub == "9":
                    warn(input("Text: "))

                elif sub == "10":
                    highlight(input("Text: "))

                elif sub == "11":
                    logo = input("Enter multiline logo:\n")
                    r = int(input("Repeat: "))
                    d = float(input("Delay: "))
                    logo_temp_live(logo, r, d)

                elif sub == "12":
                    break

        # EXIT
        elif choice == "17":
            print("Goodbye.")
            break

        else:
            print("Invalid option.")