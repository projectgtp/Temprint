# temprint/TesT/Test_module.py
# ==========================================================
#  DIGITAL WORKSPACE MANAGER (Powered by Temprint engine)
#  Uses ALL features of the Temprint module
#  Shows how ANY project becomes powerful with Temprint
# ==========================================================

import os, time, hashlib, random, zipfile, shutil

# ===== IMPORT TEMPRINT =====
from temprint.core.tempprint import (
    tprint, temp_print, inline_print, overwrite_print, line,
    header, box, success, error, warn, highlight, logo_temp_live
)

from temprint.core.file import (
    read_file, create_txt, create_py, edit_file
)

from temprint.core.terminal import (
    list_files, delete_file, rename_file, copy_file, move_file,
    change_dir, goto_sdcard
)

from temprint.core.project import create_python_project

from temprint.core.ai import (
    ai_generate, ai_explain_file, ai_summarize_file
)


# ==========================================================
#  MENU UI (Style B)
# ==========================================================

def menu():
    header("DIGITAL WORKSPACE MANAGER")
    tprint("""
[1] Smart File Inspector
[2] Folder Cleaner
[3] Backup & Restore
[4] Notes Manager
[5] ZIP Cracking Lab
[6] Task Manager
[7] Read File
[8] Timer & Stopwatch
[9] Password Generator
[10] Encryption Lab
[11] Folder Compare
[12] AI File Analyzer
[13] AI Folder Summary
[14] Workspace Navigator
[15] Project Auto-Generator
[16] Code Editor
[17] Animated UI Demo
[0] Exit
""")
    return input("Choose: ")


# ==========================================================
# 1) Smart File Inspector
# ==========================================================

def smart_file_inspector():
    path = input("File path: ")
    if not os.path.exists(path):
        error("File not found")
        return

    size = os.path.getsize(path)
    ext = os.path.splitext(path)[1]
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()

    box(f"""
Smart File Report
-----------------
Path: {path}
Size: {size} bytes
Type: {ext}
SHA-256: {sha}
""")
    success("Done!")


# ==========================================================
# 2) Folder Cleaner
# ==========================================================

def folder_cleaner():
    folder = input("Folder: ")
    if not os.path.isdir(folder):
        error("Invalid folder")
        return

    removed = 0
    for f in os.listdir(folder):
        if f.endswith((".log", ".tmp", ".cache")):
            os.remove(os.path.join(folder, f))
            removed += 1

    success(f"Removed {removed} temp files")


# ==========================================================
# 3) Backup & Restore
# ==========================================================

def backup_restore():
    src = input("Folder to backup: ")
    dst = input("Backup name (zip): ")

    shutil.make_archive(dst.replace(".zip",""), "zip", src)
    success("Backup created successfully")


# ==========================================================
# 4) Notes Manager
# ==========================================================

NOTES = "notes.txt"

def notes_manager():
    header("NOTES")
    tprint("[1] Add\n[2] View\n[3] Clear")
    ch = input("Select: ")

    if ch == "1":
        note = input("Note: ")
        with open(NOTES, "a") as f:
            f.write(note + "\n")
        success("Saved!")

    elif ch == "2":
        if os.path.exists(NOTES):
            highlight(read_file(NOTES))
        else:
            warn("No notes yet")

    elif ch == "3":
        delete_file(NOTES)
        success("Cleared!")


# ==========================================================
# 5) ZIP Cracking Lab
# ==========================================================

def zip_cracker():
    zip_path = input("ZIP file: ")
    wordlist = input("Wordlist: ")

    if not os.path.exists(zip_path) or not os.path.exists(wordlist):
        error("File not found")
        return

    z = zipfile.ZipFile(zip_path)
    for word in read_file(wordlist).split("\n"):
        try:
            z.extractall(pwd=word.encode())
            success(f"Password found: {word}")
            return
        except:
            overwrite_print(f"Trying: {word}")

    error("Password not found")


# ==========================================================
# 6) Task Manager
# ==========================================================

TASKS = "tasks.txt"

def task_manager():
    header("TASKS")
    tprint("[1] Add\n[2] View\n[3] Clear")
    ch = input("Choose: ")

    if ch == "1":
        create_txt(TASKS, input("Task: ") + "\n")
        success("Added")

    elif ch == "2":
        if os.path.exists(TASKS):
            highlight(read_file(TASKS))
        else:
            warn("No tasks")

    elif ch == "3":
        delete_file(TASKS)
        success("Cleared")


# ==========================================================
# 7) File Reader
# ==========================================================

def file_reader():
    path = input("File path: ")
    if os.path.exists(path):
        highlight(read_file(path))
    else:
        error("Not found")


# ==========================================================
# 8) Timer & Stopwatch
# ==========================================================

def timer_stopwatch():
    header("TIME TOOLS")
    tprint("[1] Timer\n[2] Stopwatch")
    ch = input("Choose: ")

    if ch == "1":
        sec = int(input("Seconds: "))
        for i in range(sec, 0, -1):
            overwrite_print(f"Time left: {i}")
            time.sleep(1)
        success("Done!")
    else:
        start = time.time()
        input("Press Enter to stop...")
        end = time.time()
        success(f"Elapsed: {end-start:.2f}s")


# ==========================================================
# 9) Password Generator
# ==========================================================

def password_generator():
    length = int(input("Length: "))
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()"
    pwd = "".join(random.choice(chars) for _ in range(length))
    box(f"Generated Password:\n{pwd}")


# ==========================================================
# 10) Encryption Lab (XOR)
# ==========================================================

def encryption_lab():
    txt = input("Text: ")
    key = input("Key: ")
    enc = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i,c in enumerate(txt))
    box(f"Encrypted:\n{enc}")


# ==========================================================
# 11) Folder Compare
# ==========================================================

def folder_compare():
    f1 = input("Folder 1: ")
    f2 = input("Folder 2: ")

    s1, s2 = set(os.listdir(f1)), set(os.listdir(f2))
    box(f"""
Only in {f1}: {list(s1 - s2)}
Only in {f2}: {list(s2 - s1)}
Common: {list(s1 & s2)}
""")


# ==========================================================
# 12) AI File Analyzer
# ==========================================================

def ai_file_analyzer():
    path = input("File: ")
    if not os.path.exists(path):
        error("Not found")
        return
    tprint(ai_explain_file(path))


# ==========================================================
# 13) AI Folder Summary
# ==========================================================

def ai_folder_summary():
    folder = input("Folder: ")
    files = "\n".join(os.listdir(folder))
    tprint(ai_generate(f"Summarize these files:\n{files}"))


# ==========================================================
# 14) Workspace Navigator (uses change_dir + goto_sdcard)
# ==========================================================

def workspace_navigator():
    header("NAVIGATOR")
    tprint("[1] Change Directory\n[2] Go to /sdcard")
    ch = input("Choose: ")

    if ch == "1":
        path = input("Path: ")
        tprint(change_dir(path))
    else:
        tprint(goto_sdcard())


# ==========================================================
# 15) Project Auto-Generator
# ==========================================================

def project_generator():
    name = input("Project name: ")
    create_python_project(name)
    success("Project created!")


# ==========================================================
# 16) Code Editor
# ==========================================================

def code_editor():
    path = input("File to edit: ")
    edit_file(path)
    success("Updated!")


# ==========================================================
# 17) Animated UI Demo
# ==========================================================

def animated_ui():
    logo = """
███╗   ███╗███████╗███╗   ███╗██████╗ 
████╗ ████║██╔════╝████╗ ████║╚════██╗
██╔████╔██║█████╗  ██╔████╔██║ █████╔╝
██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔═══╝ 
██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗
╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝
"""
    logo_temp_live(logo, 2, 0.05)


# ==========================================================
# MAIN LOOP
# ==========================================================

def main():
    while True:
        choice = menu()

        if choice == "1": smart_file_inspector()
        elif choice == "2": folder_cleaner()
        elif choice == "3": backup_restore()
        elif choice == "4": notes_manager()
        elif choice == "5": zip_cracker()
        elif choice == "6": task_manager()
        elif choice == "7": file_reader()
        elif choice == "8": timer_stopwatch()
        elif choice == "9": password_generator()
        elif choice == "10": encryption_lab()
        elif choice == "11": folder_compare()
        elif choice == "12": ai_file_analyzer()
        elif choice == "13": ai_folder_summary()
        elif choice == "14": workspace_navigator()
        elif choice == "15": project_generator()
        elif choice == "16": code_editor()
        elif choice == "17": animated_ui()

        elif choice == "0":
            success("Goodbye!")
            break

        input("\nPress Enter...")


if __name__ == "__main__":
    main()