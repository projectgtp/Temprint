"""
TEMPRINT MODULE INIT
Loads:
- Print System
- File Tools
- Terminal Tools
- Project Automation
- AI Engine
"""

from .core.tempprint import (
    tprint,
    temp_print,
    inline_print,
    overwrite_print,
    line,
    header,
    box,
    success,
    error,
    warn,
    highlight,
    logo_temp_live,
)

from .core.file import (
    read_file,
    create_txt,
    create_py,
    edit_file,
)

from .core.project import (
    create_python_project,
)

from .core.terminal import (
    list_files,
    delete_file,
    rename_file,
    copy_file,
    move_file,
    change_dir,
    goto_sdcard,
)

from .core.ai import (
    ai_generate,
    ai_explain_file,
    ai_summarize_file,
)

__all__ = [
    # Print System
    "tprint",
    "temp_print",
    "inline_print",
    "overwrite_print",
    "line",
    "header",
    "box",
    "success",
    "error",
    "warn",
    "highlight",
    "logo_temp_live",

    # File Tools
    "read_file",
    "create_txt",
    "create_py",
    "edit_file",

    # Project Tools
    "create_python_project",

    # Terminal Tools
    "list_files",
    "delete_file",
    "rename_file",
    "copy_file",
    "move_file",
    "change_dir",
    "goto_sdcard",

    # AI Tools
"ai_generate",
"ai_explain_file",
"ai_summarize_file"
]