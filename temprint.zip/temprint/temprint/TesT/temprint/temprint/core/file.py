import os
import subprocess
import shutil

# ============================
#  READ FILE
# ============================

def read_file(path: str) -> str:
    """Read any text file safely."""
    if not os.path.exists(path):
        return f"[ERROR] File not found: {path}"

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"[ERROR] Cannot read file: {e}"


# ============================
#  CREATE TXT FILE
# ============================

def create_txt(path: str, text: str = "") -> str:
    """Create a .txt file with content."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return f"[OK] TXT file created: {path}"
    except Exception as e:
        return f"[ERROR] Failed to create TXT: {e}"


# ============================
#  CREATE PY FILE
# ============================

def create_py(path: str, code: str = "") -> str:
    """Create a Python file with content."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
        return f"[OK] Python file created: {path}"
    except Exception as e:
        return f"[ERROR] Failed to create PY: {e}"


# ============================
#  EDIT FILE (UNIVERSAL EDITOR)
# ============================

def edit_file(path: str) -> str:
    """
    Edit file in the system editor.
    Termux: uses 'nano'
    Linux: nano or vi
    Windows: notepad
    macOS: open in TextEdit
    """

    # Auto-create file if doesn't exist
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write("")

    # Windows
    if os.name == "nt":
        try:
            subprocess.call(["notepad.exe", path])
            return f"[OK] Edited: {path}"
        except:
            return "[ERROR] Cannot open Notepad"

    # Termux / Linux / macOS
    editor = None

    # Termux + Linux
    if shutil.which("nano"):
        editor = "nano"
    elif shutil.which("vi"):
        editor = "vi"

    # macOS
    elif sys.platform == "darwin":
        try:
            subprocess.call(["open", path])
            return f"[OK] Edited: {path}"
        except:
            return "[ERROR] macOS file open failed"

    # cannot find editor
    if not editor:
        return "[ERROR] No editor found (nano/vi/notepad)."

    # open editor
    try:
        subprocess.call([editor, path])
        return f"[OK] Edited: {path}"
    except Exception as e:
        return f"[ERROR] Failed to edit: {e}"