import time
import sys
import shutil
import os
import random

# ============================
#  BASIC PRINT FUNCTIONS
# ============================

def tprint(text: str):
    """Normal clean print."""
    print(text)


def temp_print(text: str, delay: float = 5):
    cols = shutil.get_terminal_size().columns

    # Limit text to terminal width
    if len(text) > cols - 2:
        text = text[:cols - 2]

    # ---- STEP 1: TYPING ANIMATION ----
    for i in range(1, len(text) + 1):
        sys.stdout.write("\r" + text[:i] + " " * (cols - i))
        sys.stdout.flush()
        time.sleep(0.05)

    # ---- STEP 2: HOLD FULL TEXT ----
    time.sleep(delay)

    # ---- STEP 3: DUST DISSOLVE ERASE ----
    chars = list(text)
    positions = list(range(len(chars)))
    random.shuffle(positions)

    for pos in positions:
        chars[pos] = " "
        line = "".join(chars)
        sys.stdout.write("\r" + line + " " * (cols - len(line)))
        sys.stdout.flush()
        time.sleep(0.04)

    # ---- STEP 4: CLEAR LINE ----
    sys.stdout.write("\r" + " " * cols + "\r")
    sys.stdout.flush()


def inline_print(text: str):
    """
    Print without newline.
    Useful for continuous output.
    """
    sys.stdout.write(text)
    sys.stdout.flush()


def overwrite_print(text: str):
    """
    Overwrite previous line with new text.
    Example:
        overwrite_print("Progress: 40%")
    """
    sys.stdout.write("\r" + " " * shutil.get_terminal_size().columns)
    sys.stdout.write("\r" + text)
    sys.stdout.flush()


# ============================
#  FORMATTED PRINT TOOLS
# ============================

def line(length: int = 40):
    """Simple divider line."""
    print("-" * length)


def header(text: str):
    """Section header."""
    print(f"===== {text} =====")


def box(text: str):
    """Text inside a simple clean box."""
    length = len(text) + 4
    top = "+" + "-" * length + "+"
    mid = "|  " + text + "  |"
    bot = "+" + "-" * length + "+"
    print(top)
    print(mid)
    print(bot)


def success(text: str):
    print(f"[OK] {text}")


def error(text: str):
    print(f"[ERROR] {text}")


def warn(text: str):
    print(f"[WARN] {text}")


def highlight(text: str):
    """Simple highlight effect."""
    print(f">> {text} <<")



# ============================
#  LIVE LOGO (CUSTOM FEATURE)
# ============================

def logo_temp_live(logo: str, repeat: int = 5, delay: float = 1):
    """
    Show → hide → show → hide (live blinking logo).
    Useful for branding or startup screens.

    Example:
        logo_temp_live(logo_text, repeat=3, delay=1)
    """
    lines = logo.count("\n") + 1

    for _ in range(repeat):
        # Show logo
        print(logo)
        sys.stdout.flush()
        time.sleep(delay)

        # Clear logo block
        for _ in range(lines):
            sys.stdout.write("\033[F")  # Move cursor up
            sys.stdout.write("\033[K")  # Clear line
        sys.stdout.flush()

        time.sleep(delay)