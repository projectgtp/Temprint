import os
import shutil
from .tempprint import error, success, warn


# ============================
#  LIST FILES
# ============================

def list_files(path: str = "."):
    """List all files & folders in a directory."""
    try:
        return os.listdir(path)
    except Exception as e:
        error(f"Cannot list directory: {e}")
        return []


# ============================
#  DELETE FILE
# ============================

def delete_file(path: str) -> str:
    """Delete a file safely."""
    if not os.path.exists(path):
        return error(f"File not found: {path}")

    try:
        os.remove(path)
        return success(f"Deleted: {path}")
    except Exception as e:
        return error(f"Cannot delete file: {e}")


# ============================
#  RENAME FILE
# ============================

def rename_file(old: str, new: str) -> str:
    """Rename a file safely."""
    if not os.path.exists(old):
        return error(f"File not found: {old}")

    try:
        os.rename(old, new)
        return success(f"Renamed → {new}")
    except Exception as e:
        return error(f"Cannot rename: {e}")


# ============================
#  COPY FILE
# ============================

def copy_file(src: str, dest: str) -> str:
    """Copy a file safely."""
    if not os.path.exists(src):
        return error(f"Source missing: {src}")

    try:
        shutil.copy(src, dest)
        return success(f"Copied → {dest}")
    except Exception as e:
        return error(f"Cannot copy: {e}")


# ============================
#  MOVE FILE
# ============================

def move_file(src: str, dest: str) -> str:
    """Move a file safely."""
    if not os.path.exists(src):
        return error(f"Source missing: {src}")

    try:
        shutil.move(src, dest)
        return success(f"Moved → {dest}")
    except Exception as e:
        return error(f"Cannot move: {e}")


# ============================
#  CHANGE DIRECTORY
# ============================

def change_dir(path: str) -> str:
    """Change terminal directory."""
    if not os.path.exists(path):
        return error(f"Path does not exist: {path}")

    try:
        os.chdir(path)
        return success(f"Directory changed → {path}")
    except Exception as e:
        return error(f"Cannot change directory: {e}")


# ============================
#  QUICK JUMP TO SDCARD (TERMUX)
# ============================

def goto_sdcard() -> str:
    """Quick jump to /sdcard (Termux only)."""

    sd = "/sdcard"

    if not os.path.exists(sd):
        return error("sdcard not found on this system.")

    try:
        os.chdir(sd)
        return success("Changed path → /sdcard")
    except Exception as e:
        return error(f"Failed to enter sdcard: {e}")