import os
import re
import ast
from bytez import Bytez
from .tempprint import error


# ============================
#  BYTEZ AI CONFIG
# ============================

BYTEZ_API_KEY = "d69d4c2d34340a0de5515dff93dcc7d4"
MODEL_ID = "Qwen/Qwen3-4B-Instruct-2507"

sdk = Bytez(BYTEZ_API_KEY)
model = sdk.model(MODEL_ID)


# ============================
#  UNIVERSAL PARSER
# ============================

def parse_ai(res):
    """Converts ALL Bytez formats into clean text."""
    try:
        if hasattr(res, "output"):
            out = res.output
            if isinstance(out, dict):
                if "choices" in out:
                    return out["choices"][0].get("content", "")
                if "content" in out:
                    return out["content"]
            return str(out)

        if isinstance(res, dict):
            if "output" in res:
                out = res["output"]
                if "choices" in out:
                    return out["choices"][0].get("content", "")
                if "content" in out:
                    return out["content"]
            if "content" in res:
                return res["content"]
            return str(res)

        if isinstance(res, str):
            return res

        return str(res)

    except:
        return str(res)


# ============================
#  UNIVERSAL PROJECT GENERATOR
# ============================

def ai_generate(prompt: str) -> str:
    """
    ONE PROMPT → FULL PROJECT GENERATOR
    Creates all file types: .py, .txt, .json, .md, etc
    (FIXED VERSION – no fallback files, no extra main.py)
    """

    # Detect project mode
    project_words = [
        "make","create","generate","project","system","app",
        "application","folder","file structure","architecture","build"
    ]
    is_project = any(w in prompt.lower() for w in project_words)

    if not is_project:
        res = model.run([{"role": "user", "content": prompt}])
        return parse_ai(res)

    print("[🚀] PROJECT MODE ENABLED")

    # ====== ROOT FOLDER ======
    words = re.findall(r"[a-zA-Z0-9]+", prompt.lower())
    ignore = {"make","create","project","app","generate","build"}
    clean = [w for w in words if w not in ignore][:3] or ["project"]

    root = "_".join(clean)
    os.makedirs(root, exist_ok=True)
    print(f"[+] Root folder: {root}")

    # ====== FORMAT PROMPT ======
    force = (
        "You are an AI project generator.\n"
        "Create a COMPLETE folder + file architecture.\n"
        "this is just EXAMPLE , you can decide what file format is.\n"
        "Return ONLY this format:\n\n"

        "FOLDERS:\n"
        "- folder/\n"
        "- folder/sub/\n\n"

        "FILES:\n"
        "- folder/main.py\n"
        "- folder/info.json\n"
        "- folder/readme.md\n\n"

        "file: folder/main.py\n```python\n# full code\n```\n\n"
        "file: folder/info.json\n```json\n{ \"a\":1 }\n```\n\n"
        "file: folder/readme.md\n```md\n# Readme\n```\n\n"

        "NO explanation."
    )

    # Ask AI for the full structure
    res = model.run([{
        "role": "user",
        "content": force + "\n\nUSER REQUEST:\n" + prompt
    }])
    text = parse_ai(res)

    # ====== PARSE FOLDERS ======
    folders = {m.rstrip("/") for m in re.findall(r"-\s*([\w\-/]+/)", text)} or {"src"}

    for f in folders:
        path = os.path.join(root, f)
        os.makedirs(path, exist_ok=True)
        print(f"[+] Folder: {path}")

    # ====== PARSE FILES ======
    file_map = {}

    # Extract defined code blocks
    for path, code in re.findall(
        r"file:\s*([\w\-/\.]+)\s*```[a-zA-Z0-9]*\s*(.*?)```",
        text,
        re.DOTALL,
    ):
        file_map[path] = code.strip()

    # Detect fallback file list (FIXED — skip root-level files)
    for m in re.findall(r"-\s*([\w\-/]+\.\w+)", text):
        if "/" not in m:
            continue    # ← FIX: no more login_system_code/main.py
        if m not in file_map:
            file_map[m] = ""

    if not file_map:
        file_map = {"src/main.py": "print('Hello from AI')"}

    # ====== FILE GENERATION ======
    def clean_code(code: str) -> str:
        code = code.replace("(```", "```").replace("```)", "```").strip()
        if code.startswith("```"):
            parts = code.split("```", 2)
            if len(parts) >= 3:
                code = parts[1] if parts[1].strip() else parts[2]
        return code.strip()

    def regen(path):
        try:
            req = f"Write FULL working code for file '{path}'. Return ONLY code."
            r = model.run([{"role":"user","content":req}])
            return clean_code(parse_ai(r))
        except:
            return ""

    final = {}

    for rel, code in file_map.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)

        content = clean_code(code)
        if not content or len(content) < 5:
            content = regen(rel)
        if not content:
            content = "# AI FAILED TO GENERATE"

        with open(full, "w", encoding="utf-8") as f:
            f.write(content)

        final[full] = content
        print(f"[+] File: {full}")

    # ====== PYTHON FIX SECTION ======
    def valid_py(code):
        try:
            ast.parse(code)
            return True
        except:
            return False

    for full, code in final.items():
        if not full.endswith(".py"):
            continue

        attempts = 0
        cur = clean_code(code)

        while attempts < 3 and not valid_py(cur):
            print(f"[FIX] {full} attempt {attempts+1}")
            try:
                req = "Fix this Python code. Return ONLY corrected code:\n" + cur
                r = model.run([{"role":"user","content":req}])
                cur = clean_code(parse_ai(r))
            except:
                pass

            attempts += 1

        with open(full, "w", encoding="utf-8") as f:
            f.write(cur)

        print("[OK]" if valid_py(cur) else "[FAIL]", full)

    print("\n[✔] FULL PROJECT GENERATED SUCCESSFULLY")
    return "PROJECT GENERATED"


# ============================
#  AI EXPLAIN FILE
# ============================

def ai_explain_file(path: str) -> str:
    if not os.path.exists(path):
        return error(f"File not found: {path}")

    try:
        text = open(path, "r", encoding="utf-8").read()
    except:
        return error("Cannot read file.")

    prompt = f"Explain this file content simply:\n{text}"
    return ai_generate(prompt)


# ============================
#  AI SUMMARIZE FILE
# ============================

def ai_summarize_file(path: str) -> str:
    if not os.path.exists(path):
        return error(f"File not found: {path}")

    try:
        text = open(path, "r", encoding="utf-8").read()
    except:
        return error("Cannot read file.")

    prompt = f"Summarize this file:\n{text}"
    return ai_generate(prompt)