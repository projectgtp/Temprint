import shutil
def edit_file(path, new_text):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_text)
        return "File updated successfully."
    except Exception as e:
        return f"Editor Error: {str(e)}"