

# 🧩 TEMPRINT — AI Powered Terminal Toolkit

Temprint is a next-generation command-line toolkit designed for developers, creators, automators, and Termux power users.

It includes:

- ⚡ Advanced print utilities  
- 🤖 AI-powered terminal (Qwen 4B via Bytez)  
- 📂 File management tools  
- 🧱 Project generator  
- 🖥 Terminal automation  
- 🔥 Live logo print system  
- 📦 Ready for Termux, Linux, Windows & macOS  

Temprint aims to become the **most powerful AI-aided CLI toolkit ever created**.

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
---

📦 TEMPRINT — Developer Toolbox Module

temprint is a private lightweight developer toolkit for:

🔹 Print styling

🔹 File tools

🔹 Terminal tools

🔹 Project automation

🔹 AI helpers



---

⚙️ Installation (Private Use)

Inside the folder:

pip install .

Or developer mode:

pip install -e .


---

🚀 Basic Usage

✔ Print Tools

from temprint import tprint, header, box, success, error, warn

tprint("Normal Text")
header("Section Title")
box("Message in a box")
success("Done!")
error("Something failed")
warn("Be careful!")


---

✔ File Tools

from temprint import read_file, create_txt, create_py, edit_file

create_txt("hello.txt", "Hello World!")
create_py("main.py", "print('Hi')")
content = read_file("hello.txt")
edit_file("hello.txt", "Updated content")


---

✔ Terminal Tools

from temprint import list_files, delete_file, rename_file, move_file, copy_file, change_dir, goto_sdcard

list_files()
rename_file("a.txt", "b.txt")
delete_file("b.txt")
move_file("test.py", "src/test.py")
copy_file("src/test.py", "copy/test.py")
change_dir("/sdcard")
goto_sdcard()


---

✔ Project Tools

from temprint import create_python_project

create_python_project("myproject")

Creates:

myproject/
 ├── main.py
 ├── README.md
 └── requirements.txt


---

✔ AI Tools

from temprint import ai_generate, ai_explain_file, ai_summarize_file

ai_generate("Make login system code")
ai_explain_file("main.py")
ai_summarize_file("largefile.py")


---

Powered by:

- **Bytez SDK**
- **Qwen/Qwen3-4B-Instruct**
- Universal response parser (fixes `None` outputs)

---

# 🖥 CLI MENU
Run from terminal:

temprint

Menu:

1. Read File


2. AI Explain File


3. AI Summarize File


4. Create TXT


5. Create PY


6. Edit File


7. Create Python Project


8. List Files


9. Delete File


10. Rename File


11. Copy File


12. Move File


13. Change Directory


14. /sdcard


15. Ask AI


16. Print Tools


17. Exit



---

# 📦 Installation

pip install temprint

Run:

temprint

---

# 🧠 AI Usage

### Ask AI from Python:
```python
from temprint import ai_generate
print(ai_generate("Explain generators"))

Explain a file:

from temprint import ai_explain_file
print(ai_explain_file("script.py"))

Summarize a file:

from temprint import ai_summarize_file
print(ai_summarize_file("data.txt"))


---

🛠 Compatibility

✔ Termux (Android)

✔ Linux

✔ Windows

✔ macOS

✔ Python 3.7+



---

📄 License

MIT License


---

🔥 Future v6+ Plans

AI IDE Mode

Plugins

Real-time terminal streaming

Auto command executor

Batch automation

File watcher tools



---

💡 About

Temprint is designed to give you speed, power, and intelligence inside any terminal.

Created for developers.
Built to evolve.
