# temprint/TesT/Test_module.py
# ==========================================================
#   TEMPRINT PRO UI – DIGITAL WORKSPACE MANAGER (v2)
#   Fully animated, premium UI, all features included
# ==========================================================

import os, time, hashlib, random, zipfile, shutil

# ======= TEMPRINT IMPORTS =======
from temprint.core.tempprint import (
    tprint, temp_print, inline_print, overwrite_print, line,
    header, box, success, error, warn, highlight, logo_temp_live
)

from temprint.core.file import (
    read_file, create_txt, create_py, edit_file
)

from temprint.core.terminal import (
    list_files, delete_file, rename_file, copy_file, move_file,
    change_dir, goto_sdcard
)

from temprint.core.project import create_python_project

from temprint.core.ai import (
    ai_generate, ai_explain_file, ai_summarize_file
)


# ==========================================================
#  PRO UI HEADER (Animated)
# ==========================================================

def ui_header():
    logo = """
████████╗███████╗███╗   ███╗██████╗ ██████╗ ██╗███╗   ██╗████████╗
╚══██╔══╝██╔════╝████╗ ████║██╔══██╗██╔══██╗██║████╗  ██║╚══██╔══╝
   ██║   █████╗  ██╔████╔██║██████╔╝██████╔╝██║██╔██╗ ██║   ██║   
   ██║   ██╔══╝  ██║╚██╔╝██║██╔═══╝ ██╔══██╗██║██║╚██╗██║   ██║   
   ██║   ███████╗██║ ╚═╝ ██║██║     ██║  ██║██║██║ ╚████║   ██║   
   ╚═╝   ╚══════╝╚═╝     ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝   ╚═╝   
"""
    logo_temp_live(logo, 1, 0.01)
    header("DIGITAL WORKSPACE MANAGER – PRO UI")


# ==========================================================
#   MAIN MENU – PRO UI
# ==========================================================

def menu():
    ui_header()

    tprint("""
 [1] Smart File Inspector      [10] Encryption Lab
 [2] Folder Cleaner            [11] Folder Compare
 [3] Backup & Restore          [12] AI File Analyzer
 [4] Notes Manager             [13] AI Folder Summary
 [5] ZIP Cracking Lab          [14] Workspace Navigator
 [6] Task Manager              [15] Project Auto-Generator
 [7] File Reader               [16] Code Editor
 [8] Timer & Stopwatch         [17] Animated UI Demo
 [9] Password Generator        [0] Exit
""")
    return input("Choose an option: ")


# ==========================================================
# 1) Smart File Inspector
# ==========================================================

def smart_file_inspector():
    path = input("File path: ")
    if not os.path.exists(path):
        error("File not found")
        return

    temp_print("Inspecting file...", 0.6)

    size = os.path.getsize(path)
    ext = os.path.splitext(path)[1]
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()

    box(f"""
📁 SMART FILE REPORT
--------------------
Path: {path}
Size: {size} bytes
Type: {ext}
SHA-256: {sha}
""")
    success("Scan complete!")


# ==========================================================
# 2) Folder Cleaner
# ==========================================================

def folder_cleaner():
    folder = input("Folder path: ")
    if not os.path.isdir(folder):
        error("Invalid folder")
        return

    temp_print("Cleaning temporary files...", 0.7)

    removed = 0
    for f in os.listdir(folder):
        if f.endswith((".log", ".tmp", ".cache")):
            os.remove(os.path.join(folder, f))
            removed += 1

    success(f"Removed {removed} temp files")


# ==========================================================
# 3) Backup & Restore
# ==========================================================

def backup_restore():
    src = input("Folder to backup: ")
    dst = input("Backup zip name: ")

    temp_print("Compressing folder...", 1)
    shutil.make_archive(dst.replace(".zip", ""), "zip", src)

    success("Backup created!")


# ==========================================================
# 4) Notes Manager (UI Improved)
# ==========================================================

NOTES = "notes.txt"

def notes_manager():
    header("NOTES MANAGER")
    tprint("[1] Add Note   [2] View Notes   [3] Clear Notes")
    ch = input("Choose: ")

    if ch == "1":
        note = input("Write note: ")
        with open(NOTES, "a") as f:
            f.write(note + "\n")
        success("Note added")

    elif ch == "2":
        if os.path.exists(NOTES):
            highlight(read_file(NOTES))
        else:
            warn("No notes")

    elif ch == "3":
        delete_file(NOTES)
        success("All notes cleared")


# ==========================================================
# 5) ZIP Cracker (Animated)
# ==========================================================

def zip_cracker():
    zf = input("ZIP file: ")
    wl = input("Wordlist: ")

    if not os.path.exists(zf) or not os.path.exists(wl):
        error("File not found")
        return

    z = zipfile.ZipFile(zf)

    temp_print("Starting brute force...", 1.2)

    for word in read_file(wl).split("\n"):
        overwrite_print(f"Trying → {word}")
        try:
            z.extractall(pwd=word.encode())
            success(f"Password found: {word}")
            return
        except:
            pass

    error("Password not found")


# ==========================================================
# 6) Task Manager (UI Improved)
# ==========================================================

TASKS = "tasks.txt"

def task_manager():
    header("TASK MANAGER")
    tprint("[1] Add Task   [2] View Tasks   [3] Clear All")
    ch = input("Choose: ")

    if ch == "1":
        create_txt(TASKS, input("Task: ") + "\n")
        success("Task added")

    elif ch == "2":
        if os.path.exists(TASKS):
            highlight(read_file(TASKS))
        else:
            warn("No tasks found")

    elif ch == "3":
        delete_file(TASKS)
        success("Tasks cleared")


# ==========================================================
# 7) File Reader
# ==========================================================

def file_reader():
    path = input("File: ")
    if os.path.exists(path):
        highlight(read_file(path))
    else:
        error("File not found")


# ==========================================================
# 8) Timer & Stopwatch (Enhanced UI)
# ==========================================================

def timer_stopwatch():
    header("TIME TOOLS")
    tprint("[1] Timer   [2] Stopwatch")
    ch = input("Choose: ")

    if ch == "1":
        sec = int(input("Seconds: "))
        for i in range(sec, 0, -1):
            overwrite_print(f"⌛ {i} seconds left")
            time.sleep(1)
        success("Time's up!")

    else:
        start = time.time()
        input("Press Enter to stop...")
        end = time.time()
        success(f"Elapsed: {end - start:.2f}s")


# ==========================================================
# 9) Password Generator
# ==========================================================

import random
from temprint.core.tempprint import temp_print, overwrite_print

def password_generator():
    length = int(input("Length: "))

    temp_print("Generating secure password...", 0.03)

    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()"
    pwd = "".join(random.choice(chars) for _ in range(length))

    # Only what your installed module supports:
    temp_print(pwd, 5)

    overwrite_print("[OK] Password dusted away!")


# ==========================================================
# 10) Encryption Lab
# ==========================================================

def encryption_lab():
    txt = input("Message: ")
    key = input("Key: ")

    enc = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(txt))
    box(f"Encrypted Message:\n{enc}")


# ==========================================================
# 11) Folder Compare
# ==========================================================

def folder_compare():
    f1 = input("Folder 1: ")
    f2 = input("Folder 2: ")

    s1, s2 = set(os.listdir(f1)), set(os.listdir(f2))

    box(f"""
📁 FOLDER COMPARE RESULT
-------------------------
Only in {f1}: {list(s1 - s2)}
Only in {f2}: {list(s2 - s1)}
Common: {list(s1 & s2)}
""")


# ==========================================================
# 12) AI File Analyzer
# ==========================================================

def ai_file_analyzer():
    path = input("File: ")
    if not os.path.exists(path):
        error("File not found")
        return

    temp_print("AI reading file...", 1)
    tprint(ai_explain_file(path))


# ==========================================================
# 13) AI Folder Summary
# ==========================================================

def ai_folder_summary():
    folder = input("Folder: ")
    files = "\n".join(os.listdir(folder))

    temp_print("AI summarizing folder...", 1)
    tprint(ai_generate(f"Summarize these files:\n{files}"))


# ==========================================================
# 14) Workspace Navigator
# ==========================================================

def workspace_navigator():
    header("NAVIGATOR")
    tprint("[1] Change Directory   [2] Go to /sdcard")
    ch = input("Choose: ")

    if ch == "1":
        path = input("Path: ")
        tprint(change_dir(path))
    else:
        tprint(goto_sdcard())


# ==========================================================
# 15) Project Generator
# ==========================================================

def project_generator():
    name = input("Project name: ")

    temp_print("Generating project...", 1.5)
    create_python_project(name)

    success("Project created!")


# ==========================================================
# 16) Code Editor
# ==========================================================

def code_editor():
    path = input("File to edit: ")
    edit_file(path)
    success("File updated!")


# ==========================================================
# 17) Animated UI Demo
# ==========================================================

def animated_ui():
    tprint("Running animated interface...")
    logo_temp_live("TEMPRINT PRO UI", 3, 0.08)


# ==========================================================
# MAIN LOOP
# ==========================================================

def main():
    while True:
        choice = menu()

        if choice == "1": smart_file_inspector()
        elif choice == "2": folder_cleaner()
        elif choice == "3": backup_restore()
        elif choice == "4": notes_manager()
        elif choice == "5": zip_cracker()
        elif choice == "6": task_manager()
        elif choice == "7": file_reader()
        elif choice == "8": timer_stopwatch()
        elif choice == "9": password_generator()
        elif choice == "10": encryption_lab()
        elif choice == "11": folder_compare()
        elif choice == "12": ai_file_analyzer()
        elif choice == "13": ai_folder_summary()
        elif choice == "14": workspace_navigator()
        elif choice == "15": project_generator()
        elif choice == "16": code_editor()
        elif choice == "17": animated_ui()

        elif choice == "0":
            success("Goodbye!")
            break

        input("\nPress Enter...")


if __name__ == "__main__":
    main()