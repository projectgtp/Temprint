import json
import hashlib

# Mock user database (in real app, this would be a database)
USER_DATABASE = {
    "admin": "password123",
    "user": "pass123"
}

def authenticate_user(username, password):
    if username not in USER_DATABASE:
        return False
    
    # Hash the provided password and compare with stored hash
    stored_password = USER_DATABASE[username]
    entered_password = hashlib.sha256(password.encode()).hexdigest()
    
    return entered_password == stored_password