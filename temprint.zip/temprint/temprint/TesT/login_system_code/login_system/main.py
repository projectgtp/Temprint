import sys
import os
from auth.login import authenticate_user

def main():
    print("=== Login System ===")
    username = input("Enter username: ")
    password = input("Enter password: ")
    
    if authenticate_user(username, password):
        print("Login successful!")
    else:
        print("Invalid credentials. Login failed.")

if __name__ == "__main__":
    main()