# Login System

A simple Python-based login system with authentication using password hashing.

## Features
- Username and password authentication
- Password hashing using SHA-256
- Mock user database for testing

## Setup
1. Ensure Python 3.6+ is installed
2. Run the main script

## Usage